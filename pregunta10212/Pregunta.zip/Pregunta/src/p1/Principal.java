/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package p1;
import p3.*;
import p4.*;
        
/**
 *
 * @author reroes
 */
public class Principal {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        
        JugoEconomico g1 = new JugoEconomico();
        JugoEconomico g2 = new JugoEconomico();
        JugoTipoDos g3 = new JugoTipoDos();
        JugoTipoTres g4 = new JugoTipoTres();
        JugoTipoTres g5 = new JugoTipoTres();
        /*
        Agregar a la solución
        JugoTipoDos g6 = new JugoTipoDos();
        JugoTipoTres g7 = new JugoTipoTres();
        JugoEconomico g8 = new JugoEconomico();
        
        Analizar y aplicar los prinicipios SOLID, segun corresponda. Además
        revisar que el reporte sea completo, sin valores nulos.
        */
        g1.establecerVFinal();
        g2.establecerVFinal();
        g3.establecerVFinal();
        g4.establecerVFinal();
        g5.establecerVFinal();
        
        Venta v = new Venta(g1, g2, g3, g4, g5);
        v.establecerValorVenta();
        
        System.out.printf("%s", v);
    }
    
}
