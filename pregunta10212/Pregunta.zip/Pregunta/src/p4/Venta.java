/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package p4;
import p3.*;

/**
 *
 * @author reroes
 */
public class Venta {
    private Cliente cliente;
    private double valorVenta;
    private JugoEconomico jugo1;
    private JugoEconomico jugo2;
    private JugoTipoDos jugo3;
    private JugoTipoTres jugo4;
    private JugoTipoTres jugo5;
    
    public Venta(JugoEconomico g1, JugoEconomico g2, JugoTipoDos g3, 
            JugoTipoTres g4, JugoTipoTres g5){
        jugo1 = g1;
        jugo2 = g2;
        jugo3 = g3;
        jugo4 = g4;
        jugo5 = g5;
    }
    
    public void obtenerJugo1(JugoEconomico g){
        jugo1 = g;
    }
    
    public void obtenerJugo2(JugoEconomico g){
        jugo2 = g;
    }
    
    public void obtenerJugo3(JugoTipoDos g){
        jugo3 = g;
    }
    
    public void obtenerJugo4(JugoTipoTres g){
        jugo4 = g;
    }
    
    public void obtenerJugo5(JugoTipoTres g){
        jugo5 = g;
    }
    
    public void establecerValorVenta(){
        valorVenta = obtenerJugo1().obtenerVFinal() + 
                obtenerJugo2().obtenerVFinal() + 
                obtenerJugo3().obtenerVFinal() +
                obtenerJugo4().obtenerVFinal() + 
                obtenerJugo5().obtenerVFinal();
    }
    
    public double obtenerValorVenta(){
        return valorVenta;
    }
    
    public JugoEconomico obtenerJugo1(){
        return jugo1;
    }
    
    public JugoEconomico obtenerJugo2(){
        return jugo2;
    }
    
    public JugoTipoDos obtenerJugo3(){
        return jugo3;
    }
    
    public JugoTipoTres obtenerJugo4(){
        return jugo4;
    }
    
    public JugoTipoTres obtenerJugo5(){
        return jugo5;
    }
    
    @Override
    public String toString(){
        String data = String.format("Ventas del cliente %s\n"
                + "Jugo 1: %.3f\n"
                + "Jugo 2: %.3f\n"
                + "Jugo 3: %.3f\n"
                + "Jugo 4: %.3f\n"
                + "Jugo 5: %.3f\n"
                + "Total: %.2f\n",
                cliente,
                obtenerJugo1().obtenerVFinal(),
                obtenerJugo2().obtenerVFinal(),
                obtenerJugo3().obtenerVFinal(),
                obtenerJugo4().obtenerVFinal(),
                obtenerJugo5().obtenerVFinal(),
                obtenerValorVenta());
        return data;
    }
    
}
