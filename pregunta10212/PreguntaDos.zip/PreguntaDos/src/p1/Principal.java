/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package p1;

import p2.*;
import p3.TiposTrajes;

/**
 *
 * @author reroes
 */
public class Principal {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        
        TiposTrajes tipos = new TiposTrajes();
        TrajeTipo01 t1 = new TrajeTipo01();
        t1.establecerNombre("Típico");
        t1.establecerValorVenta();
        
        TrajeTipo02 t2 = new TrajeTipo02();
        t2.establecerNombre("Formal");
        t2.establecerValorVenta();
        
        TrajeTipo03 t3 = new TrajeTipo03();
        t3.establecerNombre("Escuela");
        t3.establecerValorVenta();
        
        TrajeTipo01 t4 = new TrajeTipo01();
        t4.establecerNombre("Playa");
        t4.establecerValorVenta();
        
        /*
        Agregar a la solución
        TrajeTipo01 t6
        TrajeTipo02 t7
        TrajeTipo03 t8
        
        Analizar y aplicar los prinicipios SOLID, segun corresponda. Además
        revisar que el reporte sea completo.
        */
        
        
        tipos.establecerTrajeTipo01(t1);
        tipos.establecerTrajeTipo02(t2);
        tipos.establecerTrajeTipo03(t3);
        tipos.establecerTrajeTipo04(t4);
        
        tipos.establecerPromedioVentas();
        
        // al usar el toString, presentar un reporte completo
        System.out.printf("%s\n", tipos);
        
    }
    
}
