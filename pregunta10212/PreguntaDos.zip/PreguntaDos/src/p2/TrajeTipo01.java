/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package p2;

/**
 *
 * @author reroes
 */
public class TrajeTipo01 {
    private String nombre;
    private double valorVenta;
    
    public void establecerNombre(String n){
        nombre = n;
    }
    
    public void establecerValorVenta(){
        // valor venta = base / adicional /
        valorVenta = 4.2 + 2.3;
    }
    
    public String obtenerNombre(){
        return nombre;
    }
    
    public double obtenerValorVenta(){
        return valorVenta;
    }
    
    
}
