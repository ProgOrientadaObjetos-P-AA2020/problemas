/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package p2;

/**
 *
 * @author reroes
 */
public class TrajeTipo03 {
    private String nombre;
    private double valorVenta;
    
    public void establecerNombre(String n){
        nombre = n;
    }
    
    public void establecerValorVenta(){
        // valor venta = base / adicional 01 / adicional 02
        valorVenta = 4.2 + 1.3 + 2.1;
    }
    
    public String obtenerNombre(){
        return nombre;
    }
    
    public double obtenerValorVenta(){
        return valorVenta;
    }
    
    
}
