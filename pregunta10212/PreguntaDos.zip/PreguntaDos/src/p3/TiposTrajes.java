/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package p3;

import p2.*;

/**
 *
 * @author reroes
 */
public class TiposTrajes {
    
    private double promedioVentas;
    private TrajeTipo01 traje1;
    private TrajeTipo02 traje2;
    private TrajeTipo03 traje3;
    private TrajeTipo01 traje4;
    
    public void establecerTrajeTipo01(TrajeTipo01 t){
        traje1 = t;
    }
    
    public void establecerTrajeTipo02(TrajeTipo02 t){
        traje2 = t;
    }
    
    public void establecerTrajeTipo03(TrajeTipo03 t){
        traje3 = t;
    }
    
    public void establecerTrajeTipo04(TrajeTipo01 t){
        traje4 = t;
    }
    
    public TrajeTipo01 obtenerTrajeTipo01(){
        return traje1;
    }
    
    public TrajeTipo02 obtenerTrajeTipo02(){
        return traje2;
    }
    
    public TrajeTipo03 obtenerTrajeTipo03(){
        return traje3;
    }
    
    public TrajeTipo01 obtenerTrajeTipo04(){
        return traje4;
    }

    public void establecerPromedioVentas(){
        promedioVentas = traje1.obtenerValorVenta() + traje2.obtenerValorVenta()
                + traje3.obtenerValorVenta() + traje4.obtenerValorVenta();
    }
    
    public double obtenerPromedioVentas(){
        return promedioVentas;
    }
    
    @Override
    public String toString(){
        return String.format("%.2f", obtenerPromedioVentas());
    }

}
